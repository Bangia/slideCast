package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class settingPageObjects {
	
	WebDriver ldriver;
	WebDriverWait wait;
	
	//Initialise constructor
	public settingPageObjects(WebDriver rdriver) {
		ldriver= rdriver;
		PageFactory.initElements(rdriver, this);
	}

	//Locator
	
	@FindBy(xpath="//b[normalize-space()='Settings']")
	@CacheLookup
	WebElement settingSideMenu;
	
	@FindBy(xpath="//*[@id='accordion3']/div[1]/a/i")
	@CacheLookup
	WebElement ComplianceResponse;
	
	@FindBy(xpath="//h3[normalize-space()='Guided, Broadcast, & Self-Guided Form Options']")
	@CacheLookup
	WebElement GbsArrowClick;
	
	//Company 
	@FindBy(xpath="//input[@formcontrolname='responseCompany']")
	@CacheLookup
	WebElement CompanyTextField;
	
	//Support Number
	@FindBy(xpath="//input[@formcontrolname='helpResponseSupportNumber']")
	@CacheLookup
	WebElement helpResponseSupportNumber;
	
	//Help Link
	@FindBy(xpath="//input[@formcontrolname='helpResponseLink']")
	@CacheLookup
	WebElement HelpLink;
	
	@FindBy(xpath="//button[contains(text(),'Update Compliance')]")
	@CacheLookup
	WebElement complianceBtn;
	
	
	
	
	//Action Method
	
	public void SettingMenuClic() {
		settingSideMenu.click();
	}
	
	public void complianceArrow() {
		if(ComplianceResponse.isEnabled()) {
			ComplianceResponse.click();
		}
		else {
			System.out.println("compliance arrow click");
		}
		
	}
	
	
	public void companyName (String cName) throws InterruptedException {
		
		CompanyTextField.clear();
		CompanyTextField.sendKeys(cName);
	}
	
	public void SupportNumber(String helpLineNumber) throws InterruptedException {
		
		helpResponseSupportNumber.clear();
		helpResponseSupportNumber.sendKeys(helpLineNumber);
	}
	
	public void helpTextField (String help) throws InterruptedException {
		
		HelpLink.clear();
		HelpLink.sendKeys(help);
	}
	
	public void complianceButton(){
		complianceBtn.click();
	}
	
	public void GbsArrowIcon() {
		
		
		if(GbsArrowClick.isEnabled()) {
			ComplianceResponse.click();
		}
		else {
			System.out.println("arrow already click");
		}
		
	}
	
	
	
}
