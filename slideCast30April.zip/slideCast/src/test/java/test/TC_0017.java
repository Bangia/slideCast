package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.Assert;


import pageObjects.loginApp;
import pageObjects.presentationPageObjects;

public class TC_0017 extends baseClass {
	
// TC_0017 : verify help me build out button able to click
	
	@Test
	public void helpBuildOut() throws InterruptedException {
		
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		
		driver.manage().timeouts().implicitlyWait(15000, TimeUnit.SECONDS);
		
		//Help me build out script starts here
		
		presentationPageObjects ppo = new presentationPageObjects(driver);
	
		
		ppo.helpButton();
		ppo.helpTextAreaField("Free Flow text");
		ppo.toggleEnable();
		ppo.selectFilesfield();
		ppo.uploadbtn();
		ppo.helpMeButtonSubmit();
		
		//assertion:
		
		String ActualMessage = driver.findElement(By.xpath("//div[@aria-label='A member of our team will get back to you shortly.']")).getText();
		System.out.print(ActualMessage);
		
		String ExpectedMessage = "A member of our team will get back to you shortly.";
		
		Assert.assertEquals(ActualMessage, ExpectedMessage, "Message Not Matched");
		
		Thread.sleep(5000);
		
		driver.close();
		
		
	}
	
	

}
