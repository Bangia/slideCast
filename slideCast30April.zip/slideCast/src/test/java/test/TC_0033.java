package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.loginApp;
import pageObjects.settingPageObjects;

public class TC_0033 extends baseClass{
//TC_0033 : Compliance Responses to Text Messaging
	
	
	@Test
	public void complianceResponse() throws InterruptedException, IOException {
		

		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
        logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		logger.info("Button is Clicked !!!");
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		//Compliance Responses to Text Messaging case starts here
		settingPageObjects spo = new settingPageObjects(driver);
		spo.SettingMenuClic();
		logger.info("Setting tab clicked !!!");
		
		spo.complianceArrow();
		logger.info("compliance expand arrow clicked !!!");
		spo.companyName("Sample Inc India");
		Thread.sleep(3000);
		logger.info("company name entered !!!");
		Thread.sleep(3000);
		spo.helpTextField("http://bit.ly/exmpl");
		logger.info("url is enetered");
		Thread.sleep(3000);
		spo.SupportNumber("(800) 123-4568");
		logger.info("phone number enetered");
		Thread.sleep(3000);
		spo.complianceButton();
		logger.info("compliance button clicked");
		
		//Assertion:
		
		String ActualMessage = driver.findElement(By.xpath("//div[@aria-label='Compliance']")).getText();
		System.out.println(ActualMessage);
		
		
		String expectedMessage = "Compliance";
		
		
		if(ActualMessage.equals(expectedMessage)) {
			Assert.assertTrue(true);
			logger.info("Test case passed compliance data saved");
			Thread.sleep(8000);
			driver.close();
			
			
		}
		else {
			captureScreen(driver,"TC_0001");
			Assert.assertTrue(false);
			reportLog("Test case failed compliance data not saved");
			
			
		}
		
	}
	
	
}
