package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;

public class TC_0062 extends baseClass {
	
// TC_0062: Verify cross icon in import popup

	@Test
	public void paginationPageSelection() throws InterruptedException, IOException {
		
		
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		loginApp lp = new loginApp(driver);

		//********** Login via phone code starts here *******************************************************
		lp.mobileRadioClick();
		logger.info("Mobile Radio Button Clicked");
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		
		
		lp.mobileNumbTxtField(mobileNumber_baseClass);
		logger.info("Entered mobile number");
		
		lp.mobilePwdTxtField(password_mobileNumber_baseClass);
		logger.info("Entered Password");
		
		lp.mobileSbtBtn();
		logger.info("Mobile button Clicked !!");
		
		lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
		logger.info("OTP entered !!");
		
		lp.otpSubmit();
		logger.info("OTP verified and button clicked !!");
		
		//********** Login done and above OTP code end here **************************************************
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		
		
		//Create contact link code starts here...
		contactPageObjects cpo = new contactPageObjects(driver);
		
		Thread.sleep(6000);
		
		cpo.contactLink();
		logger.info("Contact Link Clicked");
		Thread.sleep(5000);
		cpo.hamburgerIconClick();
		logger.info("mat icon Clicked");
		Thread.sleep(3000);
		cpo.importContactLink();
		Thread.sleep(3000);
		
		WebElement crossIcon = driver.findElement(By.xpath("//*[@id='modalImport']/div/div/div[1]/div/mat-icon"));
		
		
		if(crossIcon.isDisplayed()) {
			crossIcon.click();
			logger.info("cross icon Clicked, Test Case Passed");
			Thread.sleep(3000);
			driver.close();
		}
		else
		{
			logger.info("cross icon Not Clicked, Test Case Failed");
			Thread.sleep(3000);
			
		}
		
		
	}
		
	}
	


