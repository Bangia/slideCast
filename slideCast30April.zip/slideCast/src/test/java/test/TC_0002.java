package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import pageObjects.loginApp;

public class TC_0002 extends baseClass{

// TC_0002 : Verify that login with Mobile working fine as per expected behaviour
	
	
	@Test (groups = {"Sanity"})
	public void LoginWithMobile() throws InterruptedException, IOException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
//		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		System.out.println("driver"+driver);
		
		//********** Login via phone code starts here *******************************************************
		lp.mobileRadioClick();
		logger.info("Mobile Radio Button Clicked");
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		
		
		lp.mobileNumbTxtField(mobileNumber_baseClass);
		logger.info("Entered mobile number");
		
		lp.mobilePwdTxtField(password_mobileNumber_baseClass);
		logger.info("Entered Password");
		
		lp.mobileSbtBtn();
		logger.info("Mobile button Clicked !!");
		
		lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
		logger.info("OTP entered !!");
		
		lp.otpSubmit();
		logger.info("OTP verified and button clicked !!");
		
		//********** Login done and above OTP code end here **************************************************
		
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		//added url as verification:
		
		
		Thread.sleep(8000);
		String ActualMessage = driver.findElement(By.xpath("//div[@class='welcome-message']")).getText();
		System.out.println(ActualMessage);
		
		
		String expectedMessage = "Ready to create a presentation?";
		
		
		if(ActualMessage.equals(expectedMessage)) {
			Assert.assertTrue(true);
			logger.info("Login test passed");
			Thread.sleep(8000);
			driver.close();
			
			
		}
		else {
			captureScreen(driver,"TC_0002");
			Assert.assertTrue(false);
			reportLog("Test case Failed");
			
			
		}
		
		
		
	}
	
	
	
	
	
}
