package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;

public class TC_0060 extends baseClass {
	
// TC_0060: Verify that cross icon is working fine import contact pop up

	@Test
	public void crossIconImportContactPopup() throws InterruptedException, IOException {
		
		
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		loginApp lp = new loginApp(driver);

		//********** Login via phone code starts here *******************************************************
		lp.mobileRadioClick();
		logger.info("Mobile Radio Button Clicked");
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		
		
		lp.mobileNumbTxtField(mobileNumber_baseClass);
		logger.info("Entered mobile number");
		
		lp.mobilePwdTxtField(password_mobileNumber_baseClass);
		logger.info("Entered Password");
		
		lp.mobileSbtBtn();
		logger.info("Mobile button Clicked !!");
		
		lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
		logger.info("OTP entered !!");
		
		lp.otpSubmit();
		logger.info("OTP verified and button clicked !!");
		
		//********** Login done and above OTP code end here **************************************************
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
		
		
		//Create contact link code starts here...
		contactPageObjects cpo = new contactPageObjects(driver);
		
		Thread.sleep(6000);
		
		cpo.contactLink();
		logger.info("Contact Link Clicked");
		Thread.sleep(3000);
		cpo.hamburgerIconClick();
		
		logger.info("hamburger icon Clicked");
		Thread.sleep(3000);
		cpo.importContactLink();
		logger.info("Import Contact link clicked");
		driver.findElement(By.xpath("//label[normalize-space()='Select your File']")).click();
		
//		String ActualMessage = driver.findElement(By.xpath("//div[normalize-space()='Self-Guided Link']")).getText();
//		System.out.println(ActualMessage);
//		
//		
//		String expectedMessage = "Self-Guided Link";
//		
//		
//		if(ActualMessage.equals(expectedMessage)) {
//			Assert.assertTrue(true);
//			logger.info("test case passed as self-guided link clicked");
//			Thread.sleep(8000);
//			driver.close();
//			
//			
//		}
//		else {
//			captureScreen(driver,"TC_0058");
//			Assert.assertTrue(false);
//			reportLog("test case failed as self-guided link not clicked");
//			
//			
//		}
//		
		
		//PENDING TO COMPLETE
		
	}
		
	}
	


