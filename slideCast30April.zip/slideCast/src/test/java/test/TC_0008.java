package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;

public class TC_0008 extends baseClass {
	
//TC_0008 : Verify that able to save all fields in contact field	
	
	@Test
	public void createContact() throws InterruptedException, IOException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		
		
		logger.info("click button clicked");
		
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		
		
		//create contact
		
		contactPageObjects cpo = new contactPageObjects(driver);
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		cpo.contactLink();
		logger.info("contact side menu link clicked");
	Thread.sleep(4000);
		cpo.createContactButton();
		logger.info("Create Contact button clicked");
		cpo.FirstName("Neil");
		logger.info("Firs tName entered");
		cpo.LastName("bangia");
		logger.info("Last Name entered");
		cpo.Mobile("9999999995");
		logger.info("Mobile Number entered");
		cpo.Email("pandey26@gmail.com");
		logger.info("Email ID entered");
		cpo.UpperSaveBtn();
		logger.info("Save Button Clicked");
		Thread.sleep(4000);
		
		
		//Assertion
		
		
		
		String ActualMessaage = driver.findElement(By.xpath("//div[@class='toast-info ngx-toastr ng-trigger ng-trigger-flyInOut']")).getText();
        System.out.println(ActualMessaage);
		
        String ExpectedMessaage = "has been saved.";
        
        if(ActualMessaage.contains(ExpectedMessaage)) {
        	Assert.assertTrue(true);
        	logger.info("Test cases Passed !!!");
        }
        else {
        	captureScreen(driver,"TC_0008");
        	Assert.assertTrue(false);
        	logger.error("Test cases Passed !!!");
        }
		
		
		//driver.close();
		
	
	
	
	
	}
	
	

}
