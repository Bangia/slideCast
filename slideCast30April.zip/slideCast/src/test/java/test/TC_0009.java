package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;

public class TC_0009 extends baseClass {

//TC_0009 : Verify that able to edit contact fields
	
	
	@Test
	public void editContact() throws InterruptedException, IOException {
		
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		
		
		//create contact
		
		contactPageObjects cpo = new contactPageObjects(driver);
		cpo.contactLink();
		logger.info("create contact link clicked");
		cpo.rowHover();
		logger.info("Hover row to select contact clicked");
		Thread.sleep(6000);
		cpo.showClick();
		logger.info("clicked to edit");
		
		cpo.Company("Orbque");
		cpo.Job_title("Orbque");
		cpo.Work_Phone("9711718167");
		cpo.Home_Phone("9711718167");
		cpo.Address1("Noida");
		cpo.Address2("Noida");
		cpo.Address3("Noida");
		cpo.city("Uttar Prdaesh");
		cpo.postalCode("201301");
		cpo.Notes("Free flow text");
		cpo.customId1("test");
		cpo.customId2("test");
		cpo.LowerSaveBtn();
		
		//assertion
		Thread.sleep(5000);
		
		String ActualMessaage = driver.findElement(By.xpath("//div[@class='toast-info ngx-toastr ng-trigger ng-trigger-flyInOut']")).getText();
        System.out.println(ActualMessaage);
		
        String ExpectedMessaage = "has been saved.";
        
        if(ActualMessaage.contains(ExpectedMessaage)) {
        	Assert.assertTrue(true);
        	logger.info("Test cases passed !!!");
        	driver.close();
        	
        }
        else {
        	 captureScreen(driver,"TC_0009 - Edit Contact)");
        	Assert.assertTrue(false);
        	logger.info("Test cases failed !!!");
        }
        
    
        
     
		
		
		
	}
	
	  
	
	
}
