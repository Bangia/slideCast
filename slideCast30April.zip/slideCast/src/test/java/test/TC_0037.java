package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.loginApp;
import pageObjects.presentationPageObjects;

public class TC_0037 extends baseClass{
	
//TC_0037: Presentation Back button
	
	
	@Test
	public void presentationBackBtn() throws InterruptedException, IOException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
			logger.info("URL is opened");
			
			loginApp lp = new loginApp(driver);
			//********** Login via phone code starts here *******************************************************
			lp.mobileRadioClick();
			logger.info("Mobile Radio Button Clicked");
			
			driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
			
			
			
			lp.mobileNumbTxtField(mobileNumber_baseClass);
			logger.info("Entered mobile number");
			
			lp.mobilePwdTxtField(password_mobileNumber_baseClass);
			logger.info("Entered Password");
			
			lp.mobileSbtBtn();
			logger.info("Mobile button Clicked !!");
			
			lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
			logger.info("OTP entered !!");
			
			lp.otpSubmit();
			logger.info("OTP verified and button clicked !!");
			
			//********** Login done and above OTP code end here **************************************************
			logger.info("Button is Clicked !!!");
			
			driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
			
			//Presentaion back button
			
			
			presentationPageObjects ppo = new presentationPageObjects(driver);
			
			ppo.presentationLinkClick();
			logger.info("presentation link Clicked !!!");
			
			driver.findElement(By.xpath("/html/body/app-root/body/app-presentations-v3/div[1]/div[1]/div[2]/div[1]/div/div/div[4]/div[1]/div/img")).click();
			logger.info("presentation image Clicked !!!");
			
			Thread.sleep(4000);
			
			driver.findElement(By.xpath("//div[@class='back-home-label']")).click();
			logger.info("BreadCrumbs Clicked !!!");
		
			
			String actualMessage = driver.findElement(By.xpath("//div[@class='welcome-message']")).getText();
			
			String expectedMessage = "Ready to create a presentation?";
			
			if(actualMessage.equals(expectedMessage)) {
				Assert.assertTrue(true);
				logger.info("Test case passed");
				Thread.sleep(8000);
				driver.close();
				
			}
			else {
				captureScreen(driver,"TC_0037");
				Assert.assertTrue(false);
				reportLog("Test case Failed");
			}
			
			
			
			
		
	}
	
	
}
