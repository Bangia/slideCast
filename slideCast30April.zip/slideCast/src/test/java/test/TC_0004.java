package test;

import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.loginApp;

public class TC_0004 extends baseClass {
	
//	TC_0004 : verify that forget password link should be working fine 	
	
	@Test
	public void forgetPassword() throws InterruptedException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		lp.forgetLink();
		logger.info("Forget password link clicked !!!");
		
		
		
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		lp.setForgetPasswordText(emailId_baseClass);
		logger.info("Email ID enetered!!!");
		
		//password click button code starts here 
		
		lp.forgetSendLink();
		logger.info("Link sent to forget password");
		
		String Actualmessage = driver.findElement(By.xpath("//div[@aria-label='A link has been sent to your email address. Please use it to reset your password.']")).getText();
		System.out.println(Actualmessage);
		
		String expectedMessage = forget_toastMessage_baseClass;
		
		
		
		Assert.assertEquals(Actualmessage, expectedMessage, "Message not matched");
		
		
		driver.close();
		
		
		
	}
	

}
