package test;

import java.util.concurrent.TimeUnit;

import org.testng.*;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import pageObjects.loginApp;
import pageObjects.profilePageObjects;

public class TC_0022 extends baseClass {
// TC_0022 : Verify able to click logout button
	
	@Test
	public void VerifyLogoutLink() throws InterruptedException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				Thread.sleep(8000);
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		
		
		profilePageObjects ppo = new profilePageObjects(driver);
		
		
		WebElement ProfileLink = driver.findElement(By.xpath("/html/body/app-root/body/app-nav-menu-v3/div[1]/header/nav/div[1]/div/ul/li[5]/div/div/div"));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", ProfileLink);
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.MILLISECONDS);
		ppo.lgtLink();
		
		String ActualURL = driver.getCurrentUrl();
		System.out.println(ActualURL);
		
		String ExpectedURL = "https://dev.slidecast.com/login";
		
		//assertion validation
		
		if(ActualURL.equals(ExpectedURL)) {
			Assert.assertTrue(true);
			System.out.println("TEST CASE PASSED PAGE NAVIGATED TO LOGIN PAGE !!!");
		}
		else {
			Assert.assertTrue(false);
			System.out.println("TEST CASE FAILED PAGE NOT NAVIGATED TO LOGIN PAGE !!!");
		}
		
		Thread.sleep(4000);
		driver.close();
		
	
		
		
	}
	
	
	
	

}
