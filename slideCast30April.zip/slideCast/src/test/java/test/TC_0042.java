package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.loginApp;
import pageObjects.presentationPageObjects;

public class TC_0042 extends baseClass{
// TC_0042: Click on 3 dots button of any slide : Copy Link
	
	
	@Test
	public void presentationSettingButton() throws InterruptedException, IOException {
		
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		
//		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		
		//Setting Button in presentation starts here.....
		
		presentationPageObjects ppo = new presentationPageObjects(driver);
		ppo.presentationLinkClick();
		logger.info("Presentation button clicked !!");
		
		Thread.sleep(3000);
		ppo.hamicon();
		logger.info("hamburger icon clicked !!");
		Thread.sleep(3000);
		ppo.copyButton();
		logger.info("Copy link clicked !!");
		
		Thread.sleep(8000);
		
		
		//Assertion
		String ActualMessage = driver.findElement(By.xpath("//*[normalize-space()='Your Presentation link has been copied to your clipboard.']")).getText();
		System.out.println(ActualMessage);
		
		
		String expectedMessage = "Your Presentation link has been copied to your clipboard.";
		
		
		if(ActualMessage.equals(expectedMessage)) {
			Assert.assertTrue(true);
			logger.info("Login test passed");
			Thread.sleep(8000);
			driver.close();
			
			
		}
		else {
			captureScreen(driver,"TC_0042");
			Assert.assertTrue(false);
			reportLog("Test case Failed");
			
			
		}
		
		
		
		

		
	}
	
	
	
	
}
