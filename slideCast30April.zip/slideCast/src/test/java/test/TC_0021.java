package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.loginApp;
import pageObjects.profilePageObjects;

public class TC_0021 extends baseClass{
	
// TC_0021 : verify able to save password
	
	@Test
	public void PasswordChange() throws InterruptedException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				Thread.sleep(6000);
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
	
		profilePageObjects ppo = new profilePageObjects(driver);
		ppo.profileclick();
		Thread.sleep(2000);
		ppo.securityLinkText();
		Thread.sleep(2000);
		ppo.currentPassword(password_baseClass);
		Thread.sleep(2000);
		ppo.newPassword("Dipl0mat@qa");
		Thread.sleep(2000);
		ppo.reEnterPassword("Dipl0mat@qa");
		Thread.sleep(2000);
		
		ppo.updatePwdBtn();
		
		//assertion on password change
		
		String ActualpasswordToastMessage = driver.findElement(By.xpath("//div[@aria-label='was updated successfully']")).getText();
		System.out.println(ActualpasswordToastMessage);
		
		String ExpectedpasswordToastMessage = "was updated successfully";
		
		if(ActualpasswordToastMessage.equals(ExpectedpasswordToastMessage)) {
			Assert.assertTrue(true);
			System.out.println("Password Updated Success Case is passed");
		}
		else {
			Assert.assertTrue(false);
			System.out.println("Password Updated failed Case is failed");
		}
		
		Thread.sleep(4000);
		driver.close();
	
	
	}
	
	
	
	
	
}
