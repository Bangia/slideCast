package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;

public class TC_0023 extends baseClass {
// TC_0023: Verify that search functionality
	
	@Test
	public void searchFunctionality() throws InterruptedException, IOException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		logger.info("Button is Clicked !!!");
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.MILLISECONDS);
		
		
		//Call contact page object
		
		contactPageObjects cpo = new contactPageObjects(driver);
		cpo.contactLink();
		logger.info("contack link Clicked !!!");
		//cpo.searchText("pandey12@gmail.com");
		
		//Assestion code starts here 
		
		String ActualText = driver.findElement(By.xpath("//span[normalize-space()='successteam@slidecast.com']")).getText();
		System.out.println(ActualText);
		String ExpectedMessage = "successteam@slidecast.com";
		
		if (ActualText.contains(ExpectedMessage)) {
			Assert.assertTrue(true);
			logger.info("Search is working fine Test case passed !!!");
			Thread.sleep(8000);
			driver.close();
		}
		else {
			captureScreen(driver,"TC_0023");
			Assert.assertTrue(false);
			reportLog("Search Not working fine Test case failed !!!");
		}
		
		
		
		
	}
	
	

}
