package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.SupportPageObjects;
import pageObjects.loginApp;

public class TC_0019 extends baseClass {
	
	
	
//TC_0019 : verify that able to send support query.
	
	@Test
	public void supportQuery() throws InterruptedException {
		
		
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		//Create object of LoginApp
		loginApp lp = new loginApp(driver);
		
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		
		
		//Support query code starts here....
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		SupportPageObjects hpg = new SupportPageObjects(driver);
		
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
		
		hpg.SupporticonClick();
		
		hpg.SupportTxt("Free flow text");
		
		
		
		//hpg.arrowClick();
		
		hpg.arrowValue();
		
		driver.findElement(By.xpath("//button[normalize-space()='Send your Support Request']")).click();
		
		String Actualmessage = driver.findElement(By.xpath("//div[@class='toast-info ngx-toastr ng-trigger ng-trigger-flyInOut']")).getText();
		System.out.println(Actualmessage);
		
		String expectedMessage = "Thank you Your request has been sent. We will get back to your shortly.";
		
		if(Actualmessage.contains("Thank you") && expectedMessage.contains("Thank you")) {
			Assert.assertTrue(true);
		}
		else {
			Assert.assertTrue(false);
		}
		//Assert.assertEquals(Actualmessage, expectedMessage, "Titles of the website do not match");
		
		Thread.sleep(4000);
		driver.close();
		
	}
	

}
