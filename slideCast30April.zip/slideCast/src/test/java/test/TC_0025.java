package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;

public class TC_0025 extends baseClass {

//TC_0025 : Verify that Self Guided link is sent or not
	
	@Test
	public void Self_Guided_link() throws InterruptedException, IOException {
		
		

		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		
		//Call contact page object
		
		contactPageObjects cpo = new contactPageObjects(driver);
		cpo.contactLink();
		//cpo.SelfGuidedButtonClick();
		
		//Assertion
		
		driver.findElement(By.xpath("//span[normalize-space()='Birthday Mystery Gift']")).click();
		

		String ActualValue = driver.findElement(By.xpath("//div[@aria-label='Self-Guided Link']")).getText();
		System.out.println(ActualValue);
		String ExpectedValue = "Self-Guided Link";
		
		if (ActualValue.contains(ExpectedValue)) {
			Assert.assertTrue(true);
			logger.info("Mat icon clicked Test case passed");
			Thread.sleep(8000);
			driver.close();
		}
		else {
			captureScreen(driver,"TC_0025");
			Assert.assertTrue(false);
			logger.info("Mat icon Not clicked Test case failed");
		}
		
		
		
	
	
	}
	
}
