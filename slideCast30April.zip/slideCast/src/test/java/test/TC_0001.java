package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.loginApp;

public class TC_0001 extends baseClass {
	
//TC_0001 : Verify that login with email working fine as per expected behaviour
	
	@Test (groups = {"smoke-test"})
	public void loginEmail() throws InterruptedException, IOException {
	
		
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		
		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		lp.setEmail(emailId_baseClass);
		logger.info("Entered username");
		
		lp.setPassword(password_baseClass);
		logger.info("Entered password");
		
		lp.clickBtn();
		logger.info("Button is Clicked !!!");
		
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		//added url as verification:
		
		
		Thread.sleep(8000);
		String ActualMessage = driver.findElement(By.xpath("//div[@class='welcome-message']")).getText();
		System.out.println(ActualMessage);
		
		
		String expectedMessage = "Ready to create a presentation?";
		
		
		if(ActualMessage.equals(expectedMessage)) {
			Assert.assertTrue(true);
			logger.info("Login test passed");
			Thread.sleep(8000);
			driver.close();
			
			
		}
		else {
			captureScreen(driver,"TC_0001");
			Assert.assertTrue(false);
			logger.error("Test cases Failed");
			
			
		}
		
		
			
		
	
	}
	
	
	

}
