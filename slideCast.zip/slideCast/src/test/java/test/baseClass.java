package test;

public class baseClass {

}
