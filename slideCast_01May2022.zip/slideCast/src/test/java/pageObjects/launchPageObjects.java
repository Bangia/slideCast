package pageObjects;

import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class launchPageObjects {

WebDriver ldriver;
	
	public launchPageObjects(WebDriver rdriver) {
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	//**************************************** LOCATORS ************************************************************	
	
	@FindBy(xpath="//b[normalize-space()='Launch']")
	@CacheLookup
	WebElement launchLink;
	
	
	@FindBy(xpath="//button[@class='btn btn-gun mat-tooltip-trigger']")
	@CacheLookup
	WebElement createContactBtn;
	
	
	@FindBy(xpath="//input[@formcontrolname ='firstName']")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(xpath="//input[@formcontrolname ='lastName']")
	@CacheLookup
	WebElement LastName;
	
	@FindBy(xpath="//input[@formcontrolname ='mobile']")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(xpath="//input[@formcontrolname ='email']")
	@CacheLookup
	WebElement email;
	
	@FindBy(xpath="//button[normalize-space()='Save & Launch']")
	@CacheLookup
	WebElement saveLaunchbtn;
	
	//Here it will click row[1] as default
	@FindBy(xpath="//app-nav-menu-v3//mat-row[1]//mat-cell[5]//button[1]")
	@CacheLookup
	WebElement selfGuidedBtn;
	
	
	
	
	
	//**************************************** Action Methods ************************************************************	
	
	
	public void launLinkText() {
		launchLink.click();
	}
	
	public void contactCreateBtn() {
		createContactBtn.click();
	}
	
	
	public void setFirstName(String fName) {
		firstName.sendKeys(fName);
	}

	public void setLastName(String lName) {
		LastName.sendKeys(lName);
	}
	
	public void setMobile(String mob) {
		mobile.sendKeys(mob);
	}
	
	public void setEmail(String emailId) {
		email.sendKeys(emailId);
	}
	
	public void saveLaunchBtnClick() {
		saveLaunchbtn.click();
	}
	
	public void selfGuidedBtn() {
		if(selfGuidedBtn.isDisplayed()) {
			selfGuidedBtn.click();
			Assert.assertTrue(true);
			System.out.print("Button displayed hence test case passed..");
		}
		else {
			Assert.assertTrue(false);
			System.out.print("Button Not displayed hence test case failed..");
		}
	}
	
	

}
