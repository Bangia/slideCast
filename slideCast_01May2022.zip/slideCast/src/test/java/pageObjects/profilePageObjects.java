package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class profilePageObjects {
	
WebDriver ldriver;
	
	//Initialise constructor
	public profilePageObjects(WebDriver rdriver) {
		ldriver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	//********************** Locators ******************************************************************
	
	//Note this xpath you need to change based on your ICON as we cannot handle this other way in angular
	@FindBy(xpath="(//div[@class='text-block'])[1]")
	@CacheLookup
	WebElement profileIcon;
	
	@FindBy(xpath="//span[normalize-space()='Log out']")
	@CacheLookup
	WebElement logoutLink;
	
	
	@FindBy(xpath="//span[normalize-space()='Profile']")
	@CacheLookup
	WebElement profileEditLink;
	
	
	//Profile edit locators starts here...
	//First Name
	
	@FindBy(xpath="/html/body/app-root/body/app-profile/div/div[1]/div/div/form/div/div/div[2]/div[1]/div[1]/div/input")
	@CacheLookup
	WebElement fName;
	
	//last name
	@FindBy(xpath="/html/body/app-root/body/app-profile/div/div[1]/div/div/form/div/div/div[2]/div[1]/div[2]/div/input")
	@CacheLookup
	WebElement lName;
	
	
	//Mobile
	@FindBy(xpath="/html/body/app-root/body/app-profile/div/div[1]/div/div/form/div/div/div[2]/div[2]/div[1]/div/input")
	@CacheLookup
	WebElement mob;
	
	
	//email
	@FindBy(xpath="/html/body/app-root/body/app-profile/div/div[1]/div/div/form/div/div/div[2]/div[2]/div[2]/div/input")
	@CacheLookup
	WebElement email;
	
	//Address 1
	@FindBy(xpath="/html/body/app-root/body/app-profile/div/div[1]/div/div/form/div/div/div[2]/div[3]/div[1]/div/input")
	@CacheLookup
	WebElement add1;
	
	//Address 2
	@FindBy(xpath="/html/body/app-root/body/app-profile/div/div[1]/div/div/form/div/div/div[2]/div[3]/div[2]/div/input")
	@CacheLookup
	WebElement add2;
	
	//Address 3
	@FindBy(xpath="/html/body/app-root/body/app-profile/div/div[1]/div/div/form/div/div/div[2]/div[3]/div[3]/div/input")
	@CacheLookup
	WebElement add3;
	
	//City
	@FindBy(xpath="/html/body/app-root/body/app-profile/div/div[1]/div/div/form/div/div/div[2]/div[4]/div[1]/div/input")
	@CacheLookup
	WebElement city;
	
	//zip code
	@FindBy(xpath="/html/body/app-root/body/app-profile/div/div[1]/div/div/form/div/div/div[2]/div[4]/div[3]/div/input")
	@CacheLookup
	WebElement zipCode;
	
	@FindBy(xpath="//button[@class='btn btn-spacer btn-gun']")
	@CacheLookup
	WebElement saveBtn;
	
	//Security Locators starts here 
	
	@FindBy(xpath="//span[normalize-space()='Security']")
	@CacheLookup
	WebElement securityLink;
	
	@FindBy(id="password0")
	@CacheLookup
	WebElement currentPwd;
	
	@FindBy(id="password1")
	@CacheLookup
	WebElement newPwd;
	
	@FindBy(xpath="//input[@formcontrolname='password2']")
	@CacheLookup
	WebElement reneterPwd;
	
	@FindBy(xpath="//button[@class='btn btn-spacer btn-gun']")
	@CacheLookup
	WebElement updatePasswordBtn;
	
	//********************** Action Methods ******************************************************************
	
	
	public void profileclick() {
		profileIcon.click();
	}
	
	public void lgtLink() {
		logoutLink.click();
	}
	
	public void FirstName(String firstNameValue) {
		fName.clear();
		fName.sendKeys(firstNameValue);
		
	}
	public void LastName(String lastNameValue) {
		lName.clear();
		lName.sendKeys(lastNameValue);
	}
	
	public void Mobile(String mobileValue) {
		mob.clear();
		mob.sendKeys(mobileValue);
	}
	
	public void Email(String emailID) {
		email.clear();
		email.sendKeys(emailID);
	}
	
	public void Address1(String address1Value) {
		add1.clear();
		add1.sendKeys(address1Value);
	}
	
	public void Address2(String address2Value) {
		add2.clear();
		add2.sendKeys(address2Value);
	}
	
	public void Address3(String address3Value) {
		add3.clear();
		add3.sendKeys(address3Value);
	}
	
	public void cityName(String cityValue) {
		city.clear();
		city.sendKeys(cityValue);
	}
	
	public void zipCodetxt(String zipCodeValue) {
		zipCode.clear();
		zipCode.sendKeys(zipCodeValue);
	}
	
	public void profileEdtLink() {
		profileEditLink.click();
	}
	
	public void saveButton() {
		saveBtn.click();
	}
	
	
	//Security Link action method starts here
	
	public void securityLinkText() {
		securityLink.click();
	}
	
	public void currentPassword(String currentPWD) {
		currentPwd.sendKeys(currentPWD);
	}
	public void newPassword(String newPWD) {
		newPwd.sendKeys(newPWD);
	}
	
	public void reEnterPassword(String reEnterPWD) {
		reneterPwd.sendKeys(reEnterPWD);
	}
	
	public void updatePwdBtn() {
		updatePasswordBtn.click();
	}

}
