package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import test.baseClass;

public class contactPageObjects{

	WebDriver ldriver;
	WebDriverWait wait;
	
	//Initialise constructor
	public contactPageObjects(WebDriver rdriver) {
		ldriver= rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	
	
	//********************** Locators ******************************************************************
	
	@FindBy(xpath="//b[normalize-space()='Contacts']")
	@CacheLookup
	WebElement contactTab;
	
	@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/div/div/div/div[1]/div[2]/div[2]/div[2]/button/span")
	@CacheLookup
	WebElement createContactBtn;
	
	@FindBy(xpath="//button[@value='save'][normalize-space()='Save']")
	@CacheLookup
	WebElement saveBtn;
	
	//Create Contact
	
	@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[3]/div[1]/div/input")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[3]/div[2]/div/input")
	@CacheLookup
	WebElement LastName;
	
	@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[4]/div[1]/div[1]/div[2]/input")
	@CacheLookup
	WebElement mobile;
	
	@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[4]/div[2]/div[1]/input")
	@CacheLookup
	WebElement email;
	
	

	//Address 1
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[8]/div[1]/div/input")
		@CacheLookup
		WebElement add1;
		
		//Address 2
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[8]/div[2]/div/input")
		@CacheLookup
		WebElement add2;
		
		//Address 3
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[8]/div[3]/div/input")
		@CacheLookup
		WebElement add3;
		
		//City
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[9]/div[1]/div/input")
		@CacheLookup
		WebElement city;
		
		//zip code
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[9]/div[3]/div/input")
		@CacheLookup
		WebElement zipCode;
		
		@FindBy(xpath="//button[@class='btn btn-spacer btn-gun']")
		@CacheLookup
		WebElement saveLowerBtn;
		
		
		//Edit company name company
		
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[6]/div[1]/div/input")
		@CacheLookup
		WebElement companyField;
		
		//job title
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[6]/div[2]/div/input")
		@CacheLookup
		WebElement jobField;
		
		
		//work phone
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[7]/div[1]/div/input")
		@CacheLookup
		WebElement workPhonefield;
		
		//home phone
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[7]/div[2]/div/input")
		@CacheLookup
		WebElement homePhonefield;
		
		//notes
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[10]/div/div/textarea")
		@CacheLookup
		WebElement notesfield;
		
		//custom1
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[12]/div[1]/div/input")
		@CacheLookup
		WebElement cust1field;
		
		//custom2
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[12]/div[2]/div/input")
		@CacheLookup
		WebElement cust2field;
		
		
		@FindBy(xpath="//app-contacts-v3[@class='ng-star-inserted']//mat-row[1]//mat-cell[1]")
		@CacheLookup
		WebElement rowClick;
		
		@FindBy(xpath="//i[normalize-space()='Show more']")
		@CacheLookup
		WebElement showMoreLink;
		
		@FindBy(xpath="//div[@class='form-group col-sm-12 text-center']//button[@class='btn btn-gun'][normalize-space()='Save']")
		@CacheLookup
		WebElement lowerButtonSave;
		
		
		//hamburger icon:
		
		@FindBy(xpath="//div[@class='float-right more-all-contacts']//mat-icon[@role='img'][normalize-space()='more_vert']")
		@CacheLookup
		WebElement hamburgericon;
		
		@FindBy(xpath="//label[@for='mat-checkbox-4-input']//span[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin']")
		@CacheLookup
		WebElement checkBox;
		
		@FindBy(xpath="//span[normalize-space()='Select Contacts']")
		@CacheLookup
		WebElement selectContact;
		
		@FindBy(xpath="//button[normalize-space()='Yes']")
		@CacheLookup
		WebElement yesBtn;
		
		@FindBy(xpath="//span[normalize-space()='Delete Selected Contacts']")
		@CacheLookup
		WebElement deleteselectContact;
		
		
		@FindBy(xpath="//mat-row[1]//mat-cell[9]//div[1]//button[1]//span[1]//mat-icon[1]")
		@CacheLookup
		WebElement contactMatIconTable;
		
		@FindBy(xpath="//span[normalize-space()='Start Voice Call']")
		@CacheLookup
		WebElement StartVoiceCall;
		
		@FindBy(xpath="//button[normalize-space()='Cancel Call']")
		@CacheLookup
		WebElement cancelCall;
		
		
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/form/div[1]/div/div/div[1]/div/div[3]/div/h5/label[2]")
		@CacheLookup
		WebElement historyLink;
		
		@FindBy(xpath="//i[@class='fa fa-sync-alt']")
		@CacheLookup
		WebElement refreshIcon;
		
		
		@FindBy(xpath="//span[normalize-space()='Send Text Message']")
		@CacheLookup
		WebElement sendTextLink;
		
		@FindBy(xpath="//*[@id=\"modalText\"]/div/form/div/div[2]/div[1]/div/div/textarea")
		@CacheLookup
		WebElement sendTextArea;
		
		@FindBy(xpath="//div[@class='form-group col-sm-6']//button[@class='btn btn-gun'][normalize-space()='Send Text']")
		@CacheLookup
		WebElement sendButtonPopup;
		
		@FindBy(xpath="(//span[@class='mat-checkbox-inner-container mat-checkbox-inner-container-no-side-margin'])[1]")
		@CacheLookup
		WebElement allItem;
		
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/div/div/div/div[2]/mat-table/mat-row[1]/mat-cell[8]/button")
		@CacheLookup
		WebElement selfGuidedLink;
		
		@FindBy(xpath="//span[normalize-space()='Import']")
		@CacheLookup
		WebElement importLink;
		
		@FindBy(xpath="/html/body/app-root/body/app-contacts-v3/div/div[1]/div/div/div/div[2]/mat-paginator/div/div/div[1]/mat-form-field/div/div[1]/div")
		@CacheLookup
		WebElement pageValue;
		
	//********************** Action Methods ******************************************************************
	
	public void contactLink() {
		wait = new WebDriverWait(ldriver,30);
		 wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//b[normalize-space()='Contacts']")));
		contactTab.click();
	}
	
	public void createContactButton() {
		// wait = new WebDriverWait(ldriver,20);
		 //wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[@class='btn btn-gun help-newcontact mat-tooltip-trigger']")));
		
		createContactBtn.click();
	}
	
	public void UpperSaveBtn() {
		saveBtn.click();
	}
	
	
	public void FirstName(String firstNameValue) {
		
		firstName.sendKeys(firstNameValue);
		
	}
	public void LastName(String lastNameValue) {
		
		LastName.sendKeys(lastNameValue);
	}
	
	public void Mobile(String mobileValue) {
		
		mobile.sendKeys(mobileValue);
	}
	
	public void Email(String emailID) {
		
		email.sendKeys(emailID);
	}
	
	
	
	
	//EDIT FUNCTIONALITY 
	
	public void Company(String comp) {
		companyField.clear();
		companyField.sendKeys(comp);
	}
	
	public void Job_title(String jobTtle) {
		jobField.clear();
		jobField.sendKeys(jobTtle);
	}
	
	public void Work_Phone(String wphn) {
		workPhonefield.clear();
		workPhonefield.sendKeys(wphn);
	}
	
	public void Home_Phone(String hphn) {
		homePhonefield.clear();
		homePhonefield.sendKeys(hphn);
	}
	public void Address1(String addre1) {
		add1.clear();
		add1.sendKeys(addre1);
	}
	public void Address2(String addre2) {
		add2.clear();
		add2.sendKeys(addre2);
	}
	public void Address3(String addre3) {
		add3.clear();
		add3.sendKeys(addre3);
	}
	
	public void city(String cty) {
		city.clear();
		city.sendKeys(cty);
	}
	
	public void postalCode(String zipCodes) {
		zipCode.clear();
		zipCode.sendKeys(zipCodes);
	}
	public void Notes(String nts) {
		notesfield.clear();
		notesfield.sendKeys(nts);
	}
	public void customId1(String custId1) {
		cust1field.clear();
		cust1field.sendKeys(custId1);
	}
	public void customId2(String custId2) {
		cust2field.clear();
		cust2field.sendKeys(custId2);
	}
	public void rowHover(){
		rowClick.click();
	}
	
	public void showClick() {
		
		if(! showMoreLink.isSelected()) {
			showMoreLink.click();
		}
		else {
			//showMoreLink.click();
			System.out.print("No need to do");
		}
		
	}
	
	public void LowerSaveBtn() {
		lowerButtonSave.click();
	}
	
	public void hamburgerIconClick() {
		hamburgericon.click();
	}
	
	public void checkBoxClick() {
		checkBox.click();
	}
	
	public void selectContactClick() {
		selectContact.click();
	}
	
	public void yesButtonClick() {
		yesBtn.click();
	}
	
	public void deleteSelectedContactBtn() {
		deleteselectContact.click();
	}
	
	
	public void matIconcontactTable() {
	contactMatIconTable.click();
	}
	
	
	public void voiceCallLink() {
		StartVoiceCall.click();
	}
	
	public void cancelCallButton() {
	cancelCall.click();
	}
	
	public void historyButtonTab() {
		historyLink.click();
	}
	 
	public void  refreshedIcon() {
		refreshIcon.click();
	}
	
	
	public void sendTextButton() {
		sendTextLink.click();
	}
	
	public void messageTextArea(String msg) {
		sendTextArea.sendKeys(msg);
	}
	
	
	public void ButtonContactMessage() {
		sendButtonPopup.click();
	}
	
	public void SelectAll() {
		allItem.click();
	}
	
	public void selfGuidedLinkButton() {
		selfGuidedLink.click();
	}
	
	public void importContactLink() {
		importLink.click();
	}
	
	public void pageValueButton() {
		pageValue.click();
	}
	
}
