package pageObjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SupportPageObjects {

//**************************************** LOCATORS ************************************************************
WebDriver ldriver;
	
	public SupportPageObjects(WebDriver rdriver) {
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(xpath="//a[@class='nav-link text-dark mat-tooltip-trigger']//*[name()='svg']//*[name()='circle' and @id='BG']")
	@CacheLookup
	WebElement supportIcon;
	
	@FindBy(xpath="//textarea[@placeholder='Describe the issue or question you have here']")
	@CacheLookup
	WebElement supportTxtArea;
	
	@FindBy(xpath="//mat-select[@id='mat-select-68']//div[@class='mat-select-arrow']")
	@CacheLookup
	WebElement arrowicon;
	
	@FindBy(xpath="//span[@class='mat-option-text'][normalize-space()='Urgent']")
	@CacheLookup
	WebElement arrowTextValue;
	
	
	@FindBy(xpath="//button[normalize-space()='Send your Support Request']")
	@CacheLookup
	WebElement SupportButton;
	
	
	
//**************************************** ACTION METHODS ******************************************************	
	
	public void SupporticonClick() {
		supportIcon.click();
	}
	
	public void SupportTxt(String querySupport) {
		supportTxtArea.sendKeys(querySupport);
	}
	
	public void arrowClick() {
		arrowicon.click();	
	}
	
	public void arrowValue() {
		arrowTextValue.click();
	}
	
	public void SupportBtn() {
		SupportButton.click();
	}
	
	
}
