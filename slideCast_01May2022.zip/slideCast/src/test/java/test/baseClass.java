package test;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentTest;

import utilities.ReadConfig;

public class baseClass {

	//Call object to call Readconfi.java file
	public static WebDriver driver;
	ReadConfig readconfig = new ReadConfig();
	public static Logger logger;
	public String baseUrl = readconfig.getApplicationUrl();
	public String emailId_baseClass = readconfig.getUsername();
	public String password_baseClass = readconfig.getPassword();
	
	public static ExtentTest test;
	
	
	
	
	//Browser parameterization code
	
	@Parameters("browser")
	@BeforeClass
	public void setup(String br)
	{			
		logger = Logger.getLogger("SlideCast-Logs");
		PropertyConfigurator.configure("Log4j.properties");
		
		if(br.equals("chrome"))
		{
			System.setProperty("webdriver.chrome.driver","/Users/rst/Desktop/chromedriver");
			driver=new ChromeDriver();
		}
		
		
		else
		{
			System.setProperty("webdriver.chrome.driver","/Users/rst/Desktop/chromedriver");
			driver=new ChromeDriver();
		}
		
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get(baseUrl);
		driver.manage().window().maximize();
	}
	
	
	
	
	//Default Static method for dynamic data

	
	
	public static String forget_toastMessage_baseClass = "";
	public static String mobileNumber_baseClass = "2015550000";
	public static String password_mobileNumber_baseClass = "Fr33dom!";
	public static String otp_mobileNumber_baseClass = "579154";
	
	public void captureScreen(WebDriver driver, String tname) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		File target = new File(System.getProperty("user.dir") + "/Screenshots/" + tname + ".png");
		FileUtils.copyFile(source, target);
		System.out.println("Screenshot taken");
	}
	
	public String randomestringName()
	{
		String generatedstring=RandomStringUtils.randomAlphabetic(8);
		return(generatedstring);
	} 
	
	public static String randomeNum() {
		String generatedString2 = RandomStringUtils.randomNumeric(4);
		return (generatedString2);
	}
	
	//Method for adding logs passed from test cases
	 public void reportLog(String message) {    
	   // test.log(LogStatus.INFO, message);//For extentTest HTML report
	    logger.info("Message: " + message);
	    Reporter.log(message);

	}
	
////	@AfterClass
////	public void tearDown()
////	{
////		driver.quit();
////	}
//	

}
