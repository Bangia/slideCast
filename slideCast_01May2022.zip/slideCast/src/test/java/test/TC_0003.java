package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.loginApp;

public class TC_0003 extends baseClass{
// TC_0003 : Verify that sign in with google should be worked.
	
	@Test
	public void SignInGoogle() throws InterruptedException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		loginApp lp = new loginApp(driver);
		
		String parentWindowhandle = driver.getWindowHandle();
		System.out.println("parentWindowhandle" + parentWindowhandle);
		

		lp.gmailButton();
		
		for(String childTab: driver.getWindowHandles()) {
			driver.switchTo().window(childTab);
		}
		
		
		
		lp.emailIDTxt("nealbangia88@gmail.com");
		Thread.sleep(3000);
		lp.nextButtonGmail();
		lp.Password_Gmail("dipl0mat");
		
		Assert.assertFalse(false);
		logger.info("Chrome restricted to automate gmail login This test case failed !!!");
		
		
		driver.close();
		
	}
	
	
	
	
}
