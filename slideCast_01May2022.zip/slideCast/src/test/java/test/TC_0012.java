package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pageObjects.launchPageObjects;
import pageObjects.loginApp;

public class TC_0012 extends baseClass {

// TC_0012: Verify self guided button should be clicked
	
	@Test
	public void selfGuidedButtonClickable() throws InterruptedException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		
		
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		
		//validate self-guided button
		
		launchPageObjects lpo = new launchPageObjects(driver);
		Thread.sleep(4000);
		lpo.launLinkText();
		
		lpo.selfGuidedBtn();
		
		
		Thread.sleep(6000);
		driver.close();
		
		
		
		
		
		
	}
	
	
}
