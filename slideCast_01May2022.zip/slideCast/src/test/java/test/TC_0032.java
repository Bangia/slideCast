package test;

import java.util.concurrent.TimeUnit;

import org.testng.*;
import org.testng.annotations.Test;

import pageObjects.loginApp;
import pageObjects.settingPageObjects;

public class TC_0032 extends baseClass {
// TC_0032: Guided, Broadcast, & Self-Guided Form Options
	
	@Test
	public void guidedOptions(){
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		 logger.info("URL is opened");
			
			loginApp lp = new loginApp(driver);
			//********** Login via phone code starts here *******************************************************
			lp.mobileRadioClick();
			logger.info("Mobile Radio Button Clicked");
			
			driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
			
			
			
			lp.mobileNumbTxtField(mobileNumber_baseClass);
			logger.info("Entered mobile number");
			
			lp.mobilePwdTxtField(password_mobileNumber_baseClass);
			logger.info("Entered Password");
			
			lp.mobileSbtBtn();
			logger.info("Mobile button Clicked !!");
			
			lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
			logger.info("OTP entered !!");
			
			lp.otpSubmit();
			logger.info("OTP verified and button clicked !!");
			
			//********** Login done and above OTP code end here **************************************************
			
			driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
			
			//Compliance Responses to Text Messaging case starts here
			settingPageObjects spo = new settingPageObjects(driver);
			spo.SettingMenuClic();
			logger.info("Setting tab clicked !!!");
			
			spo.GbsArrowIcon();
	
			logger.info("Guided, Broadcast, & Self-Guided Form Options arrow clicked !!!");
			
			Assert.assertTrue(true);
	
	
	
	
	
	}
	
	
	
	
}
