package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;

public class TC_0048 extends baseClass {

//TC_0010 : Verify that able to delete contact
	
	@Test
	public void deleteContact() throws InterruptedException, IOException {

		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);

		//********** Login via phone code starts here *******************************************************
		lp.mobileRadioClick();
		logger.info("Mobile Radio Button Clicked");
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.MILLISECONDS);
		
		
		
		lp.mobileNumbTxtField(mobileNumber_baseClass);
		logger.info("Entered mobile number");
		
		lp.mobilePwdTxtField(password_mobileNumber_baseClass);
		logger.info("Entered Password");
		
		lp.mobileSbtBtn();
		logger.info("Mobile button Clicked !!");
		
		lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
		logger.info("OTP entered !!");
		
		lp.otpSubmit();
		logger.info("OTP verified and button clicked !!");
		
		//********** Login done and above OTP code end here **************************************************
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.MILLISECONDS);
		
		//DELETE CONTACT CODE STARTS HERE.....
		
		contactPageObjects cpo = new contactPageObjects(driver);
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.MILLISECONDS);
		cpo.contactLink();
		logger.info("contact link clicked");
		Thread.sleep(4000);
		cpo.hamburgerIconClick();
		logger.info("menu clicked");
		Thread.sleep(4000);
		cpo.selectContactClick();
		logger.info("contact selected");
		Thread.sleep(4000);
		cpo.checkBoxClick();
		logger.info("checkbox clicked");
		cpo.hamburgerIconClick();
		logger.info("menu clicked to delete");
		Thread.sleep(4000);
		cpo.deleteSelectedContactBtn();
		logger.info("delete clicked");
		Thread.sleep(4000);
		cpo.yesButtonClick();
		logger.info("Say Yes to delete");
		Thread.sleep(4000);
		
      String ActualMessage = driver.findElement(By.xpath("//div[contains(@aria-label,'The selected contacts have been deleted.')]")).getText();
      System.out.println(ActualMessage);
      String ExpectedMessage = "The selected contacts have been deleted.";
      
      if(ActualMessage.equals(ExpectedMessage)) {
    	  Assert.assertTrue(true);
    	  logger.info("Test case passed !!!");
    	  Thread.sleep(5000);
    	  driver.close();
    	  
      }
      else {
    	  captureScreen(driver,"TC_0010)");
    	  Assert.assertTrue(false);
    	  logger.info("Test case failed");
    	  Thread.sleep(8000);
    	  driver.close();
      
      }
		
		
		
		
		
		
		
	}

	
	
}
