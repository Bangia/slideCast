package test;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import pageObjects.anayticsPageObjects;
import pageObjects.loginApp;

public class TC_0006 extends baseClass {

// TC_0006 : Verify that Analytics link should be clickable	
	
	@Test
	public void analyticLinkClickable() throws InterruptedException {
		
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		
		//Validate analytic links:
		
		anayticsPageObjects  apo = new anayticsPageObjects(driver);
		apo.analyticLinkClick();
		logger.info("analytic link clicked");
		
		apo.tabValuetxt();
		
		//validate all links clickable 
		
		String ExpectedEnableTab = "Engagement";
		
		Assert.assertTrue(true);
		System.out.print(ExpectedEnableTab);
		
		
		Thread.sleep(3000);
		
		driver.close();
		
		
		
		
		
		
		
	}
	
	
}
