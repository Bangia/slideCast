package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;

public class TC_0024 extends baseClass {

//TC_0024 : Verify that cross icon button functionality	
	
	@Test
	public void crosssIcon() throws InterruptedException, IOException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		logger.info("Button is Clicked !!!");
		
		driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
		
		
		//Call contact page object
		
		contactPageObjects cpo = new contactPageObjects(driver);
		cpo.contactLink();
		logger.info("contack link Clicked !!!");
		//cpo.searchText("pandey12@gmail.com");
		
		//Assestion code starts here refer contactPageObjects for condition match
		Thread.sleep(5000);
		//cpo.crossIconSearchTextField();
		logger.info("condition verification from contactPageObjects !!!");
		Thread.sleep(5000);
		driver.close();
		
	
	}
	
}
