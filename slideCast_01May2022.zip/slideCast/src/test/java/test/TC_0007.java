package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.sun.tools.sjavac.Log;

import pageObjects.contactPageObjects;
import pageObjects.loginApp;


public class TC_0007 extends baseClass {

/*
TC_0007 : "Verify that application should validation message if User try to save blank contact 
i.e. without First name & Last name	
*/
	@Test
	public void ContactValidation() throws InterruptedException, IOException {
		/*
		Back up script
		 System.setProperty("webdriver.chrome.driver", "/Users/hashstudioz/Desktop/chromedriver");
		WebDriver driver = new ChromeDriver();

		
		driver.get("https://dev.slidecast.com/login");
		driver.manage().window().maximize();
		 */
		
		logger.info("URL is opened");
		loginApp lp = new loginApp(driver);
		//********** Login via phone code starts here *******************************************************
				lp.mobileRadioClick();
				logger.info("Mobile Radio Button Clicked");
				
				driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
				
				
				
				lp.mobileNumbTxtField(mobileNumber_baseClass);
				logger.info("Entered mobile number");
				
				lp.mobilePwdTxtField(password_mobileNumber_baseClass);
				logger.info("Entered Password");
				
				lp.mobileSbtBtn();
				logger.info("Mobile button Clicked !!");
				
				lp.OtphardcodedMobile(otp_mobileNumber_baseClass);
				logger.info("OTP entered !!");
				
				lp.otpSubmit();
				logger.info("OTP verified and button clicked !!");
				
				//********** Login done and above OTP code end here **************************************************
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		
		
		//Create contact link code starts here...
		contactPageObjects cpo = new contactPageObjects(driver);
		
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		
		cpo.contactLink();
		logger.info("Contact Link Clicked");
		
		Thread.sleep(5000);
		cpo.createContactButton();
		
		logger.info("create contact button clicked");
		
		cpo.UpperSaveBtn();
		logger.info("Upper save button clicked");
		
		//validation assertion starts here...
		String ActualFirstName = driver.findElement(By.xpath("//div[contains(text(),'First Name is required')]")).getText();
		
		System.out.print("ActualFirstName"+ActualFirstName);
		
		String ExpectedFirstName ="First Name is required";
		String ExpectedLastName ="Last Name is required";
		
		String ActualLastName = driver.findElement(By.xpath("//div[contains(text(),'Last Name is required')]")).getText();
		
		System.out.print("ActualLastName" + ActualLastName);
		
		if(ActualFirstName.equals(ExpectedFirstName) && ActualLastName.equals(ExpectedLastName)) {
			Assert.assertTrue(true);
			logger.info("Test case passed validation message shown");
			Thread.sleep(8000);
			driver.close();
		}
		else {
			captureScreen(driver,"TC_0007");
			Assert.assertTrue(false);
			logger.error("TC_0007 - Test cases failed");
			
		}
		
		
		
	
		
		
	
	
	
	}

	
	

}
